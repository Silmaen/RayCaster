
pak1.pak contains selected textures from FreeLanZer's High Resolution Wolfenstein Pack


---------------------------------------------------
���FreeLanZer's High Resolution Wolfenstein Pack���
---------------------------------------------------

This pack is released under Creative Commons

Read the rights here:
http://creativecommons.org/licenses/by-nc-sa/2.5/dk/deed.en

--
Jacob "FreeLanZer" �stergaard
http://freelanzer.com/
freelanzer@gmail.com

---------------------------------------------------

