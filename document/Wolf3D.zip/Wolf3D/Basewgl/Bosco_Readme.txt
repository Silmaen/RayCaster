Hello, everyone! I'm Bosco.

Here are the new (and old but improved) models for NewWolf.

I hope you like them and they enhance your Wolfenstein experience.

Feel free to modify them as long as you include this readme file and add a notification of the modifications you've made.

Any comments, send me a mail to Bosco_XXI@yahoo.com.ar, or post a message at the NewWolf forum at http://hosting.gotdotnet.ru/DarkOne/phorum/default.asp (if you are registered, of course).

Unzip the contents of the zip file to your NewWolf folder.

Well, that's it... Have fun!

Bosco.

